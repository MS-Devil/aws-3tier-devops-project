# AWS 3-Tier Scalable Inventory Management System

This project demonstrates a production-like 3-tier architecture deployed on AWS using EC2, RDS, Application Load Balancer, and Auto Scaling.

The application is a Flask-based Inventory Management System capable of handling scalable traffic and persistent storage.